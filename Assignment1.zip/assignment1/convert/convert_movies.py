import re
import json

f = open('/Users/liwenxing/Documents/DA/hw/Mongo_assignment_1_25_16/moviesdat.py', 'r')
f1 = open('/Users/liwenxing/PycharmProjects/test000/movies.py', 'w')

for line in f:
    rr = re.compile(r'[\n\|\r]')  # rr = | or return
    line = line.strip()  # eliminate space
    m = rr.sub('::', line)  # replace | with ::
    p = re.split(r'::', m)  # divide when there is ::
    list = ['movieid', 'title', 'genre']
    result = [[], [], []]
    for elements in p:
        if len(result[0]) < 1:  # result[0]=1st array, if it is empty
            result[0].append(elements)  # add elements in
        elif len(result[1]) < 1:
            result[1].append(elements)
        else:
            result[2].append(elements)
    print(result)
    dict1 = dict(zip(list, result))  # use the dictionary format
    print(dict1)
    k = json.dumps(dict1)
    f1.write(k)
f.close()
f1.close()

