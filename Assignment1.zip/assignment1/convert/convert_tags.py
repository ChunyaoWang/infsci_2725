import re
import json
f = open('/Users/liwenxing/Documents/DA/hw/Mongo_assignment_1_25_16/tagsdat.py','r')
f1 =open('/Users/liwenxing/PycharmProjects/test000/tags.py','w')
#data=f.readline()
for line in f:
   # rr=re.compile(r'[\n\|\r]')
    line = line.strip()
   # m=rr.sub('::',line)
    p=re.split(r'::',line)
    list=['UserID','MovieID','Tag','Timestamp']
    result=[[],[],[],[]]
    for elements in p:
        if len(result[0])<1:
            result[0].append(elements)
        elif len(result[1])<1:
            result[1].append(elements)
        elif len(result[2])<1:
            result[2].append(elements)
        else:
            result[3].append(elements)
    print result
    dict1=dict(zip(list,result))
    print dict1
    k=json.dumps(dict1)
   # print(k)
    f1.write(k)
f.close()
f1.close()
#print(f.readline())
