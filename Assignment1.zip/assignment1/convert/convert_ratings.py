import re
import json
f = open('/Users/liwenxing/Documents/DA/hw/Mongo_assignment_1_25_16/ratingsdat.py','r')
f1 =open('/Users/liwenxing/PycharmProjects/test000/ratings.py','w')
for line in f:
    line = line.strip()
    p=re.split(r'::',line)
    list=['UserID','MovieID','Rating','Timestamp']
    result=[[],[],[],[]]
    for elements in p:
        if len(result[0])<1:
            result[0].append(elements)
        elif len(result[1])<1:
            result[1].append(elements)
        elif len(result[2])<1:
            a=float(elements)
            result[2].append(a)
        else:
            result[3].append(elements)
    print result
    dict1=dict(zip(list,result))
    print dict1
    k=json.dumps(dict1)

    f1.write(k)
f.close()
f1.close()

